#ifndef BUTTONAPI_H
#define BUTTONAPI_H

#include "Arduino.h"
#include "MidiAPI.h"
struct ButtonState {
  uint8_t currentState;
  bool isPressed;
  bool isReleased;
};

void handleButton(int new_but_state, ButtonState * but);
void button1ToMIDI(ButtonState * but);
void button2ToMIDI(ButtonState * but);
#endif // BUTTONAPI_H