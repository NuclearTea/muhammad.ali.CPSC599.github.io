#ifndef UTILS_H
#define UTILS_H
#include "Arduino.h"

uint8_t printToSerial(String str);

#endif // UTILS_H