#include "ButtonAPI.h"

void handleButton(int new_but_state, ButtonState * but) {
  // printToSerial("New But State: " + String(new_but_state));
  const uint8_t old_but_state = but->currentState;
  if (old_but_state == new_but_state) return;

  // was released before, pressed now
  if (old_but_state == 1 && new_but_state == 0) {
    *but = {
      0,
      true,
      false
    };
  }
  // was pressed before, released now
  if (old_but_state == 0 && new_but_state == 1) {
    *but = { 1, false, true };
  }
  delay(5);
  return;
}

void button1ToMIDI(ButtonState * but) {
  if (but->isPressed) {
    playNote(PITCH, 127);
  }
}

void button2ToMIDI(ButtonState * but) {
  if (but->isPressed) {
    turnOffNote(PITCH, 127);
  }
}